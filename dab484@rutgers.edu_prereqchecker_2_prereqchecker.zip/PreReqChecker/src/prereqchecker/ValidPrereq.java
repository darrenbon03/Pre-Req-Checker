package prereqchecker;
import java.util.*;
/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * ValidPreReqInputFile name is passed through the command line as args[1]
 * Read from ValidPreReqInputFile with the format:
 * 1. 1 line containing the proposed advanced course
 * 2. 1 line containing the proposed prereq to the advanced course
 * 
 * Step 3:
 * ValidPreReqOutputFile name is passed through the command line as args[2]
 * Output to ValidPreReqOutputFile with the format:
 * 1. 1 line, containing either the word "YES" or "NO"
 */
public class ValidPrereq {
    public static void main(String[] args) {

        if ( args.length < 3 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.ValidPrereq <adjacency list INput file> <valid prereq INput file> <valid prereq OUTput file>");
            return;
        }
        String adjListInputFile = args[0];
        String prereqInputFile = args[1];
        String outputFile = args[2];

        Map<String, Set<String>> courseGraph = readAdjacencyList(adjListInputFile);
        String[] courses = readPrereqCourses(prereqInputFile);

        boolean isPossible = checkCourses(courseGraph, courses[0], courses[1]);

        StdOut.setFile(outputFile);
        StdOut.println(isPossible ? "YES" : "NO");
        StdOut.close();
    }

    private static Map<String, Set<String>> readAdjacencyList(String fileName) {
        Map<String, Set<String>> graph = new HashMap<>();
        StdIn.setFile(fileName);
    
        int numCourses = StdIn.readInt();
    
        for (int i = 0; i < numCourses; i++) {
            String course = StdIn.readString();
            graph.put(course, new HashSet<>());
        }
    
        int numPrereqs = StdIn.readInt();
        for (int i = 0; i < numPrereqs; i++) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            graph.get(course).add(prereq);
        }
    
        return graph;
    }

    private static String[] readPrereqCourses(String fileName) {
        StdIn.setFile(fileName);
        String course1 = StdIn.readString();
        String course2 = StdIn.readString();
        return new String[]{course1, course2};
    }

    private static boolean checkCourses(Map<String, Set<String>> graph, String course1, String course2) {
        graph.putIfAbsent(course1, new HashSet<>());
        graph.get(course1).add(course2);
        boolean hasCycle = dfsHasCycle(graph, course1, new HashSet<>(), new HashSet<>());
        graph.get(course1).remove(course2);

        return !hasCycle;
    }

    private static boolean dfsHasCycle(Map<String, Set<String>> graph, String current, Set<String> visited, Set<String> recStack) {
        if (recStack.contains(current)) {
            return true;
        }
        if (visited.contains(current)) {
            return false;
        }

        visited.add(current);
        recStack.add(current);

        if (graph.containsKey(current)) {
            for (String neighbor : graph.get(current)) {
                if (dfsHasCycle(graph, neighbor, visited, recStack)) {
                    return true;
                }
            }
        }

        recStack.remove(current);
        return false;
    }
}
