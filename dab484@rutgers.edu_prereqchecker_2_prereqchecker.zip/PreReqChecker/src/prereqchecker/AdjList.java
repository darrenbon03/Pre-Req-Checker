package prereqchecker;
import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * AdjListOutputFile name is passed through the command line as args[1]
 * Output to AdjListOutputFile with the format:
 * 1. c lines, each starting with a different course ID, then 
 *    listing all of that course's prerequisites (space separated)
 */
public class AdjList {
    public static void main(String[] args) {

        if ( args.length < 2 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.AdjList <adjacency list INput file> <adjacency list OUTput file>");
            return;
        }

                String inputFile = args[0];
        String outputFile = args[1];

        Map<String, Set<String>> adjList = processInput(inputFile);
        writeOutput(outputFile, adjList);
    }

    private static Map<String, Set<String>> processInput(String inputFile) {
        Map<String, Set<String>> adjList = new HashMap<>();

        StdIn.setFile(inputFile);

        int numCourses = StdIn.readInt();
        for (int i = 0; i < numCourses; i++) {
            String course = StdIn.readString();
            adjList.put(course, new HashSet<>());
        }

        int numPrereqs = StdIn.readInt();
        for (int i = 0; i < numPrereqs; i++) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            adjList.get(course).add(prereq);
        }

        return adjList;
    }

    private static void writeOutput(String outputFile, Map<String, Set<String>> adjList) {
        StdOut.setFile(outputFile);

        List<String> sortedCourses = new ArrayList<>(adjList.keySet());
        Collections.sort(sortedCourses);

        for (String course : sortedCourses) {
            StdOut.print(course);
            List<String> prereqs = new ArrayList<>(adjList.get(course));
            Collections.sort(prereqs);

            for (String prereq : prereqs) {
                StdOut.print(" " + prereq);
            }
            StdOut.println();
        }
    }
    }
