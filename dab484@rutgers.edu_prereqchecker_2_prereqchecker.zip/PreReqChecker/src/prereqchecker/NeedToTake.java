package prereqchecker;

import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * NeedToTakeInputFile name is passed through the command line as args[1]
 * Read from NeedToTakeInputFile with the format:
 * 1. One line, containing a course ID
 * 2. c (int): Number of courses
 * 3. c lines, each with one course ID
 * 
 * Step 3:
 * NeedToTakeOutputFile name is passed through the command line as args[2]
 * Output to NeedToTakeOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */
public class NeedToTake {
    public static void main(String[] args) {

        if ( args.length < 3 ) {
            StdOut.println("Execute: java NeedToTake <adjacency list INput file> <need to take INput file> <need to take OUTput file>");
            return;
        }

        String adjListInputFile = args[0];
        String needToTakeInputFile = args[1];
        String needToTakeOutputFile = args[2];

        Map<String, Set<String>> coursePrereqs = processInput(adjListInputFile);
        Pair<String, Set<String>> needToTakeData = readNeedToTakeInput(needToTakeInputFile);
        Set<String> neededCourses = findCoursesNeededToTake(coursePrereqs, needToTakeData.first, needToTakeData.second);

        writeOutput(needToTakeOutputFile, neededCourses);
    }

    private static Map<String, Set<String>> processInput(String inputFile) {
        Map<String, Set<String>> coursePrereqs = new HashMap<>();
        StdIn.setFile(inputFile);

        int numCourses = StdIn.readInt();
        for (int i = 0; i < numCourses; i++) {
            String course = StdIn.readString();
            coursePrereqs.putIfAbsent(course, new HashSet<>());
        }

        int numPrereqs = StdIn.readInt();
        for (int i = 0; i < numPrereqs; i++) {
            String course = StdIn.readString();
            String prereq = StdIn.readString();
            coursePrereqs.get(course).add(prereq);
        }

        return coursePrereqs;
    }

    private static Pair<String, Set<String>> readNeedToTakeInput(String inputFile) {
        StdIn.setFile(inputFile);

        String targetCourse = StdIn.readString();
        int numTakenCourses = StdIn.readInt();
        Set<String> takenCourses = new HashSet<>();
        for (int i = 0; i < numTakenCourses; i++) {
            takenCourses.add(StdIn.readString());
        }

        return new Pair<>(targetCourse, takenCourses);
    }

    
    private static Set<String> findCoursesNeededToTake(Map<String, Set<String>> coursePrereqs, String targetCourse, Set<String> takenCourses) {
        Set<String> neededCourses = new HashSet<>();
        Set<String> allPrereqs = new HashSet<>();
        findAllPrereqs(coursePrereqs, targetCourse, allPrereqs);

        for (String prereq : allPrereqs) {
            if (!takenCourses.contains(prereq) && !isCourseCoveredByTaken(coursePrereqs, prereq, takenCourses)) {
                neededCourses.add(prereq);
            }
        }

        return neededCourses;
    }

    private static void findAllPrereqs(Map<String, Set<String>> coursePrereqs, String course, Set<String> allPrereqs) {
        if (coursePrereqs.containsKey(course)) {
            for (String prereq : coursePrereqs.get(course)) {
                if (allPrereqs.add(prereq)) {
                    findAllPrereqs(coursePrereqs, prereq, allPrereqs);
                }
            }
        }
    }

    private static boolean isCourseCoveredByTaken(Map<String, Set<String>> coursePrereqs, String course, Set<String> takenCourses) {
        for (String taken : takenCourses) {
            if (isPrerequisiteOf(coursePrereqs, course, taken)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isPrerequisiteOf(Map<String, Set<String>> coursePrereqs, String prereq, String course) {
        if (!coursePrereqs.containsKey(course)) {
            return false;
        }
        if (coursePrereqs.get(course).contains(prereq)) {
            return true;
        }
        for (String nextCourse : coursePrereqs.get(course)) {
            if (isPrerequisiteOf(coursePrereqs, prereq, nextCourse)) {
                return true;
            }
        }
        return false;
    }

    private static void writeOutput(String outputFile, Set<String> neededCourses) {
        StdOut.setFile(outputFile);
        for (String course : neededCourses) {
            StdOut.println(course);
        }
    }

    static class Pair<T1, T2> {
        final T1 first;
        final T2 second;

        Pair(T1 first, T2 second) {
            this.first = first;
            this.second = second;
        }
    }
}
